FIVE-PARAMETER UNKNOWN-STATE REGRESSION — TRAINER PACKAGE
Input: data/noise_0p2pct/{train,val}.npz key 'gy', shape [N,100].
Targets: key 'parameters', shape [N,5], order [a1,a2,a3,m,gamma].
Use physical_state_id only to audit grouping; never as model input.
Normalize only with provided normalization_train_only.npz; target
5th coordinate uses log_gamma; invert before evaluating physical gamma.
Only use Train to fit weights, Val for tuning. No Test truth included.
Recovery gates: |da1|<=0.005; |dm|<=0.03; F_gamma<=1.2.
Test set is independently chosen and held by the evaluator.
DO NOT combine closed-set examples with this experiment for an unseen-state claim.
Passing data checks does NOT certify trained model recovery.

PRIVATE: contains held-out test labels and reproducibility metadata.
Do NOT give this archive to the model trainer before final freeze.
Evaluate final predictions against data/noise_0p2pct/test.npz,
and report each recovery gate plus their joint pass fraction.
